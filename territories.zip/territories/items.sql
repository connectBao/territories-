INSERT INTO `items` (name, label) VALUES
	('cocaine_uncut', "Uncut Cocaine"),
	('cocaine_cut', "Cut Cocaine"),
	('cocaine_packaged', "Packaged Cocaine"),
	
	('meth_raw', "Raw Meth"),
	('meth_packaged', "Packaged Meth"),
	
	('weed_untrimmed', "Untrimmed Weed"),
	('weed_packaged', "Packaged Weed"),
	
	('sorted_money', "Counterfeit Cash - Sorted"),
	('cut_money', "Counterfeit Cash - Cut")
;